Asset Sources:

Environment, player, bullet, animation and enemies:
Wapred City by Ansimuz
https://assetstore.unity.com/packages/2d/environments/warped-city-assets-pack-138128

Main menu background:
Brackeys 2D Mega Pack
https://assetstore.unity.com/packages/2d/free-2d-mega-pack-177430

Font
https://www.dafont.com/fipps.font

Scripts
Brackeys Youtube Videos